var indexSectionsWithContent =
{
  0: "dw",
  1: "w",
  2: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Файлы",
  2: "Функции"
};

